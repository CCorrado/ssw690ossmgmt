# SimpleLoginApi.Login

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userType** | **String** |  | 
**username** | **String** |  | 
**password** | **String** |  | 


<a name="UserTypeEnum"></a>
## Enum: UserTypeEnum


* `buyer` (value: `"buyer"`)

* `business` (value: `"business"`)




