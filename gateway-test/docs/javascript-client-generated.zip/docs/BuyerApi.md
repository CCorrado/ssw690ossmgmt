# SimpleLoginApi.BuyerApi

All URIs are relative to *https://virtserver.swaggerhub.com/SamNormcoreWayne/ssw690ossmgmt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addBuyer**](BuyerApi.md#addBuyer) | **POST** /register/buyer | Users registration
[**userLogin**](BuyerApi.md#userLogin) | **POST** /login | Users login


<a name="addBuyer"></a>
# **addBuyer**
> addBuyer(opts)

Users registration

Adds an new user into system

### Example
```javascript
var SimpleLoginApi = require('simple_login_api');

var apiInstance = new SimpleLoginApi.BuyerApi();

var opts = { 
  'registerInformation': new SimpleLoginApi.UserRegister() // UserRegister | 
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.addBuyer(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **registerInformation** | [**UserRegister**](UserRegister.md)|  | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="userLogin"></a>
# **userLogin**
> userLogin(opts)

Users login

Allow a user to login

### Example
```javascript
var SimpleLoginApi = require('simple_login_api');

var apiInstance = new SimpleLoginApi.BuyerApi();

var opts = { 
  'loginInformation': new SimpleLoginApi.Login() // Login | Inventory item to add
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.userLogin(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **loginInformation** | [**Login**](Login.md)| Inventory item to add | [optional] 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

