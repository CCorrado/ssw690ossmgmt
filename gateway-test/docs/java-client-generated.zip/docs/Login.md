
# Login

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userType** | [**UserTypeEnum**](#UserTypeEnum) |  | 
**username** | **String** |  | 
**password** | **String** |  | 


<a name="UserTypeEnum"></a>
## Enum: UserTypeEnum
Name | Value
---- | -----
BUYER | &quot;buyer&quot;
BUSINESS | &quot;business&quot;



