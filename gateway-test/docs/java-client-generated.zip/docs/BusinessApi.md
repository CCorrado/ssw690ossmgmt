# BusinessApi

All URIs are relative to *https://virtserver.swaggerhub.com/SamNormcoreWayne/ssw690ossmgmt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addBusiness**](BusinessApi.md#addBusiness) | **POST** /register/business | Users registration
[**userLogin**](BusinessApi.md#userLogin) | **POST** /login | Users login


<a name="addBusiness"></a>
# **addBusiness**
> addBusiness(registerInformation)

Users registration

Adds an new user into system

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BusinessApi;


BusinessApi apiInstance = new BusinessApi();
BisRegister registerInformation = new BisRegister(); // BisRegister | 
try {
    apiInstance.addBusiness(registerInformation);
} catch (ApiException e) {
    System.err.println("Exception when calling BusinessApi#addBusiness");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **registerInformation** | [**BisRegister**](BisRegister.md)|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="userLogin"></a>
# **userLogin**
> userLogin(loginInformation)

Users login

Allow a user to login

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BusinessApi;


BusinessApi apiInstance = new BusinessApi();
Login loginInformation = new Login(); // Login | Inventory item to add
try {
    apiInstance.userLogin(loginInformation);
} catch (ApiException e) {
    System.err.println("Exception when calling BusinessApi#userLogin");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **loginInformation** | [**Login**](Login.md)| Inventory item to add | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

