# BuyerApi

All URIs are relative to *https://virtserver.swaggerhub.com/SamNormcoreWayne/ssw690ossmgmt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addBuyer**](BuyerApi.md#addBuyer) | **POST** /register/buyer | Users registration
[**userLogin**](BuyerApi.md#userLogin) | **POST** /login | Users login


<a name="addBuyer"></a>
# **addBuyer**
> addBuyer(registerInformation)

Users registration

Adds an new user into system

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BuyerApi;


BuyerApi apiInstance = new BuyerApi();
UserRegister registerInformation = new UserRegister(); // UserRegister | 
try {
    apiInstance.addBuyer(registerInformation);
} catch (ApiException e) {
    System.err.println("Exception when calling BuyerApi#addBuyer");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **registerInformation** | [**UserRegister**](UserRegister.md)|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="userLogin"></a>
# **userLogin**
> userLogin(loginInformation)

Users login

Allow a user to login

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.BuyerApi;


BuyerApi apiInstance = new BuyerApi();
Login loginInformation = new Login(); // Login | Inventory item to add
try {
    apiInstance.userLogin(loginInformation);
} catch (ApiException e) {
    System.err.println("Exception when calling BuyerApi#userLogin");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **loginInformation** | [**Login**](Login.md)| Inventory item to add | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

