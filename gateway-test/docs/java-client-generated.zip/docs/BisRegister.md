
# BisRegister

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **String** |  | 
**name** | **String** |  | 
**password** | **String** |  | 
**email** | **String** |  | 
**storename** | **String** |  | 



