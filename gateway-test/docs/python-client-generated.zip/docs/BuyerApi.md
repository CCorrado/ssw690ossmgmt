# swagger_client.BuyerApi

All URIs are relative to *https://virtserver.swaggerhub.com/SamNormcoreWayne/ssw690ossmgmt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_buyer**](BuyerApi.md#add_buyer) | **POST** /register/buyer | Users registration
[**user_login**](BuyerApi.md#user_login) | **POST** /login | Users login


# **add_buyer**
> add_buyer(register_information=register_information)

Users registration

Adds an new user into system

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.BuyerApi()
register_information = swagger_client.UserRegister() # UserRegister |  (optional)

try:
    # Users registration
    api_instance.add_buyer(register_information=register_information)
except ApiException as e:
    print("Exception when calling BuyerApi->add_buyer: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **register_information** | [**UserRegister**](UserRegister.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **user_login**
> user_login(login_information=login_information)

Users login

Allow a user to login

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.BuyerApi()
login_information = swagger_client.Login() # Login | Inventory item to add (optional)

try:
    # Users login
    api_instance.user_login(login_information=login_information)
except ApiException as e:
    print("Exception when calling BuyerApi->user_login: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **login_information** | [**Login**](Login.md)| Inventory item to add | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

