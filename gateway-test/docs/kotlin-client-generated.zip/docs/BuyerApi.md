# BuyerApi

All URIs are relative to *https://virtserver.swaggerhub.com/SamNormcoreWayne/ssw690ossmgmt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addBuyer**](BuyerApi.md#addBuyer) | **POST** /register/buyer | Users registration
[**user login**](BuyerApi.md#user login) | **POST** /login | Users login


<a name="addBuyer"></a>
# **addBuyer**
> addBuyer(registerInformation)

Users registration

Adds an new user into system

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = BuyerApi()
val registerInformation : UserRegister =  // UserRegister | 
try {
    apiInstance.addBuyer(registerInformation)
} catch (e: ClientException) {
    println("4xx response calling BuyerApi#addBuyer")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling BuyerApi#addBuyer")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **registerInformation** | [**UserRegister**](UserRegister.md)|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="user login"></a>
# **user login**
> user login(loginInformation)

Users login

Allow a user to login

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = BuyerApi()
val loginInformation : Login =  // Login | Inventory item to add
try {
    apiInstance.user login(loginInformation)
} catch (e: ClientException) {
    println("4xx response calling BuyerApi#user login")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling BuyerApi#user login")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **loginInformation** | [**Login**](Login.md)| Inventory item to add | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

