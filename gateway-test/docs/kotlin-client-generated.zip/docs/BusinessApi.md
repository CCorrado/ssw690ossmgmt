# BusinessApi

All URIs are relative to *https://virtserver.swaggerhub.com/SamNormcoreWayne/ssw690ossmgmt/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**addBusiness**](BusinessApi.md#addBusiness) | **POST** /register/business | Users registration
[**user login**](BusinessApi.md#user login) | **POST** /login | Users login


<a name="addBusiness"></a>
# **addBusiness**
> addBusiness(registerInformation)

Users registration

Adds an new user into system

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = BusinessApi()
val registerInformation : BisRegister =  // BisRegister | 
try {
    apiInstance.addBusiness(registerInformation)
} catch (e: ClientException) {
    println("4xx response calling BusinessApi#addBusiness")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling BusinessApi#addBusiness")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **registerInformation** | [**BisRegister**](BisRegister.md)|  | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="user login"></a>
# **user login**
> user login(loginInformation)

Users login

Allow a user to login

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = BusinessApi()
val loginInformation : Login =  // Login | Inventory item to add
try {
    apiInstance.user login(loginInformation)
} catch (e: ClientException) {
    println("4xx response calling BusinessApi#user login")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling BusinessApi#user login")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **loginInformation** | [**Login**](Login.md)| Inventory item to add | [optional]

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

