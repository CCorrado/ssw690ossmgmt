
# BisRegister

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**username** | **kotlin.String** |  | 
**name** | **kotlin.String** |  | 
**password** | **kotlin.String** |  | 
**email** | **kotlin.String** |  | 
**storename** | **kotlin.String** |  | 



