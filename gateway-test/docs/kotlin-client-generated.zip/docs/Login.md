
# Login

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_type** | [**inline**](#User_typeEnum) |  | 
**username** | **kotlin.String** |  | 
**password** | **kotlin.String** |  | 


<a name="User_typeEnum"></a>
## Enum: user_type
Name | Value
---- | -----
user_type | buyer, business



